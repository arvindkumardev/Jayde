import Colors from './Colors';
import Images from './Images';
import Fonts from './Fonts';

export {Colors, Images,Fonts};
