const errorIcon = {
  errorCredential: require('../../assets/errorIcons/ErrorCredentials.png'),
  errorFingerId: require('../../assets/errorIcons/ErrorFingerprint.png'),
  errorFaceId: require('../../assets/errorIcons/ErrorFaceId.png'),
};
export default errorIcon;
