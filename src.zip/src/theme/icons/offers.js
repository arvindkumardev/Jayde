const Offers = {
  redeemOtp: require('../../assets/offers/redmeeOtp.png'),
  hotel: require('../../assets/offers/hotel_room.png'),
  healthWellness: require('../../assets/offers/health_wellness.png'),
  entertainment: require('../../assets/offers/attractions.png'),
  shopping: require('../../assets/offers/shopping.png'),
  dine: require('../../assets/offers/dineIn.png'),
  emaarAdvantages: require('../../assets/offers/emaar_advantages.png'),
  offerHowItWorks: require('../../assets/offers/offerHowItWorks.png'),
};
export default Offers;
