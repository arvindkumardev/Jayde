const CommonIcons = {
  downArrow: require('../../assets/common/ArrowDown.png'),
  maximise: require('../../assets/common/maximise.png'),
  minimize: require('../../assets/common/minimise.png'),
  unCheckedIcon: require('../../assets/common/unChecked.png'),
  notification: require('../../assets/common/notification.png'),
  attachment :require('../../assets/common/Attachment.png'),
  popupSuccess :require('../../assets/common/popupSuccess.png')
};

export default CommonIcons;
