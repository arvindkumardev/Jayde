const BottomTabIcons = {
  homeActiveIcon: require('../../assets/bottomTabIcons/home_active.png'),
  homeInActiveIcon: require('../../assets/bottomTabIcons/home_inactive.png'),
  offerActiveIcon: require('../../assets/bottomTabIcons/offers_active.png'),
  offerInActiveIcon: require('../../assets/bottomTabIcons/offers_inactive.png'),
  approvalActiveIcon: require('../../assets/bottomTabIcons/approvals_active.png'),
  approvalInactiveIcon: require('../../assets/bottomTabIcons/approvals_inactive.png'),
  menuInactiveIcon: require('../../assets/bottomTabIcons/menuInactiveIcon.png'),
  menuActiveIcon: require('../../assets/bottomTabIcons/menuActive.png'),
  profileActiveIcon: require('../../assets/bottomTabIcons/profile_active.png'),
  profileInactiveIcon: require('../../assets/bottomTabIcons/profile_inactive.png'),
};
export default BottomTabIcons;
