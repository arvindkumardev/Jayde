const loginIcon = {
  biometric: require('../../assets/login/biometric.png'),
  faceId: require('../../assets/login/faceId.png'),
  touchId: require('../../assets/login/touchId.png'),
  tickIcon: require('../../assets/login/Tick.png'),
  openEye: require('../../assets/login/EyeOpen.png'),
  closeEye: require('../../assets/login/EyeClose.png'),
  loginBg: require('../../assets/login/login_bg.png'),
  loginImage: require('../../assets/login/loginImage.png'),
};
export default loginIcon;
