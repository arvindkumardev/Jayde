const ApprovalIcon = {
  hr: require('../../assets/approvals/hr.png'),
  procurement: require('../../assets/approvals/procurement.png'),
  finance: require('../../assets/approvals/finance.png'),
};
export default ApprovalIcon;
