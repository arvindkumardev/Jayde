const Fonts = {
    regular: 'ProximaNova-Regular',
    mediumBold: 'ProximaNova-SemiBold',
    bold: 'ProximaNova-Bold',
};


export default Fonts;
