export const ANALYTICS_EVENTS = {
    LOGIN_EMAAR:'login_emaar',
    LOGIN_NOON:'login_noon',
    LOGIN_NAMSHI:'login_namshi',
    LOGIN_HAMPTON:'login_hampton',
    LOGIN_FAIL:'login_fail',
    NEED_HELP:'needhelp',
    ENABLE_BIOMETRIC:'enable_biometric',
    FORGOT_PASSWORD_SUBMIT:'forgot_password_submit',
    FAQS_AND_HELP:'faqs_and_help',
};
