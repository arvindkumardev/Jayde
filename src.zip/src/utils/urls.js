import { ENDPOINT } from "../utils/index";
const LOGIN_URL = `${ENDPOINT}/api/user/login`;

export {
  LOGIN_URL,
  ENDPOINT
};
