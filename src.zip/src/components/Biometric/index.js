import Biometric from './Biometric';
export default Biometric;
