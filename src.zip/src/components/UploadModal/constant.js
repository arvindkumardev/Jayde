export const OPTIONS = {
    storageOptions: {
        skipBackup: true,
        path: 'images',
    },
};
export const ALLOWED_FILE_SIZE = 2 * 1024 * 1024;